package com.example.camping22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void previousscreen(View view) {
        Internet intent=new Intent(packageContext: this,Activity2.class);
        startActivity(intent);
    }

    public void close(View view) {
        Internet intent=new Intent(packageContext: this,Activity2.class);
        startActivity(intent);s
    }
    public void close(view view){
        finish();
    }
}